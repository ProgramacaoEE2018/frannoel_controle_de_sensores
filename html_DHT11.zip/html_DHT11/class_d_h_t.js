var class_d_h_t =
[
    [ "DHT", "class_d_h_t.html#afa429167bfeba848ab824fee0043f79d", null ],
    [ "begin", "class_d_h_t.html#a757dc4b34611c08168248b276e4f84a8", null ],
    [ "computeHeatIndex", "class_d_h_t.html#a0d23921017e3d827e49bfd136b40a6aa", null ],
    [ "convertCtoF", "class_d_h_t.html#a582df4d39cd56b4acbd47fbe75aedcc3", null ],
    [ "convertFtoC", "class_d_h_t.html#a90530e38a2f47893e4767dda1d00d2a4", null ],
    [ "expectPulse", "class_d_h_t.html#a372412d3da8068d3315dd0ec8ae37adb", null ],
    [ "read", "class_d_h_t.html#a3f36687c0c3dc3978384e7524ee46f24", null ],
    [ "readHumidity", "class_d_h_t.html#a5f8c84378abe4eeecf34f09e2cdf90a0", null ],
    [ "readTemperature", "class_d_h_t.html#a68be09105aa7d831bb473c9d774918cf", null ],
    [ "_lastreadtime", "class_d_h_t.html#ab94dce88e20afc10a362f3ce0e97cb3d", null ],
    [ "_lastresult", "class_d_h_t.html#a380d11b5cd92742c065875a5beb2d560", null ],
    [ "_maxcycles", "class_d_h_t.html#a7c63e118a68c6339e97749a3431abf83", null ],
    [ "_pin", "class_d_h_t.html#a2d210036a82eec1a9e5298921cddf070", null ],
    [ "_type", "class_d_h_t.html#a07afddda78b36576edec505c3c2f4cb7", null ],
    [ "data", "class_d_h_t.html#a2144aecd4c4c1ba2741c0f2a9bbe17a4", null ]
];