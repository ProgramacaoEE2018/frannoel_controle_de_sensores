var searchData=
[
  ['computeheatindex',['computeHeatIndex',['../class_d_h_t.html#a0d23921017e3d827e49bfd136b40a6aa',1,'DHT']]],
  ['convertctof',['convertCtoF',['../class_d_h_t.html#a582df4d39cd56b4acbd47fbe75aedcc3',1,'DHT']]],
  ['convertftoc',['convertFtoC',['../class_d_h_t.html#a90530e38a2f47893e4767dda1d00d2a4',1,'DHT']]]
];
