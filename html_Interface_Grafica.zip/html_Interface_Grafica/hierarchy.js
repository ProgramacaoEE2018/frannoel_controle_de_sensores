var hierarchy =
[
    [ "Form", null, [
      [ "WindowsFormsApp1.Form1", "class_windows_forms_app1_1_1_form1.html", null ]
    ] ],
    [ "WindowsFormsApp1.Program", "class_windows_forms_app1_1_1_program.html", null ]
];