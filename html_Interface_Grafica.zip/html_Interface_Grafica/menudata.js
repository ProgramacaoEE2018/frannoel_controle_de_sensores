/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var menudata={children:[
{text:"Página Principal",url:"index.html"},
{text:"Pacotes",url:"namespaces.html",children:[
{text:"Pacotes",url:"namespaces.html"}]},
{text:"Classes",url:"annotated.html",children:[
{text:"Lista de Classes",url:"annotated.html"},
{text:"Índice dos Componentes",url:"classes.html"},
{text:"Hierarquia de Classes",url:"inherits.html"},
{text:"Membros de classe",url:"functions.html",children:[
{text:"Todos",url:"functions.html",children:[
{text:"a",url:"functions.html#index_a"},
{text:"b",url:"functions.html#index_b"},
{text:"c",url:"functions.html#index_c"},
{text:"d",url:"functions.html#index_d"},
{text:"f",url:"functions.html#index_f"},
{text:"g",url:"functions.html#index_g"},
{text:"i",url:"functions.html#index_i"},
{text:"l",url:"functions.html#index_l"},
{text:"m",url:"functions.html#index_m"},
{text:"s",url:"functions.html#index_s"},
{text:"t",url:"functions.html#index_t"},
{text:"x",url:"functions.html#index_x"}]},
{text:"Funções",url:"functions_func.html"},
{text:"Variáveis",url:"functions_vars.html"}]}]},
{text:"Arquivos",url:"files.html",children:[
{text:"Lista de Arquivos",url:"files.html"}]}]}
