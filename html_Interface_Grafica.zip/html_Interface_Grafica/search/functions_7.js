var searchData=
[
  ['label2_5fclick',['label2_Click',['../class_windows_forms_app1_1_1_form1.html#a7783222848334c3d5ba42c61ca5b8d9a',1,'WindowsFormsApp1::Form1']]],
  ['label4_5fclick',['label4_Click',['../class_windows_forms_app1_1_1_form1.html#a6244b30afa99754a4259bee430c5e8c0',1,'WindowsFormsApp1::Form1']]]
];
