var searchData=
[
  ['dispose',['Dispose',['../class_windows_forms_app1_1_1_form1.html#a794a40bb1ca26b382a8c51f6f026d823',1,'WindowsFormsApp1::Form1']]]
];
