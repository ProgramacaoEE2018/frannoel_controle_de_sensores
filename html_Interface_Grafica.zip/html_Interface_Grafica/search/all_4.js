var searchData=
[
  ['form1',['Form1',['../class_windows_forms_app1_1_1_form1.html',1,'WindowsFormsApp1.Form1'],['../class_windows_forms_app1_1_1_form1.html#af92589760ac0b9d75dfb869dd579a4b9',1,'WindowsFormsApp1.Form1.Form1()']]],
  ['form1_2ecs',['Form1.cs',['../_form1_8cs.html',1,'']]],
  ['form1_2edesigner_2ecs',['Form1.Designer.cs',['../_form1_8_designer_8cs.html',1,'']]],
  ['form1_5fformclosed',['Form1_FormClosed',['../class_windows_forms_app1_1_1_form1.html#a3892acd98ec3cd4680362bc46e60e577',1,'WindowsFormsApp1::Form1']]],
  ['form1_5fload',['Form1_Load',['../class_windows_forms_app1_1_1_form1.html#aee12e776cfb92dbecc786bf623a2af47',1,'WindowsFormsApp1::Form1']]]
];
