var searchData=
[
  ['textbox1',['textBox1',['../class_windows_forms_app1_1_1_form1.html#a3946138d9af83b7c92df22284cae338f',1,'WindowsFormsApp1::Form1']]],
  ['textbox2',['textBox2',['../class_windows_forms_app1_1_1_form1.html#afa8507963a339c330929f28f96cb7814',1,'WindowsFormsApp1::Form1']]],
  ['textbox3',['textBox3',['../class_windows_forms_app1_1_1_form1.html#a68c0cea63c2cf5067936be2311131b1f',1,'WindowsFormsApp1::Form1']]],
  ['timerx',['timerx',['../class_windows_forms_app1_1_1_form1.html#a6f37575e70aa86fa677664f870260891',1,'WindowsFormsApp1::Form1']]]
];
