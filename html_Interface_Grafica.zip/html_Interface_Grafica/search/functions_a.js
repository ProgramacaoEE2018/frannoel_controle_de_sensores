var searchData=
[
  ['textbox1_5ftextchanged',['textBox1_TextChanged',['../class_windows_forms_app1_1_1_form1.html#ad3f5e47037ea0338e5d37e4b57844840',1,'WindowsFormsApp1::Form1']]],
  ['textbox3_5ftextchanged',['textBox3_TextChanged',['../class_windows_forms_app1_1_1_form1.html#a21f871afc603d2bf11b2d768b7a13f32',1,'WindowsFormsApp1::Form1']]],
  ['timer1_5ftick',['timer1_Tick',['../class_windows_forms_app1_1_1_form1.html#a12a60802f994a4d9418121f180b2df1a',1,'WindowsFormsApp1::Form1']]],
  ['transfere',['transfere',['../class_windows_forms_app1_1_1_form1.html#aecc834ef66184150b78c2940582037bc',1,'WindowsFormsApp1::Form1']]]
];
