var searchData=
[
  ['groupbox1',['groupBox1',['../class_windows_forms_app1_1_1_form1.html#a3e65d01da3cb826b464c2fbeeb4e373a',1,'WindowsFormsApp1::Form1']]],
  ['groupbox2',['groupBox2',['../class_windows_forms_app1_1_1_form1.html#af61818136745731bd7f9a5664169af98',1,'WindowsFormsApp1::Form1']]]
];
