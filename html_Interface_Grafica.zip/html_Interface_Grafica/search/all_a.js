var searchData=
[
  ['serial',['Serial',['../class_windows_forms_app1_1_1_form1.html#a9891bc45976d4440422fa2c0387caded',1,'WindowsFormsApp1::Form1']]],
  ['sp',['SP',['../class_windows_forms_app1_1_1_form1.html#adfb5b9e4412d5244457bd450b602ca00',1,'WindowsFormsApp1::Form1']]],
  ['sp_5fdatareceived',['SP_DataReceived',['../class_windows_forms_app1_1_1_form1.html#a6759d4c119f75e63c2cf46042e2a5191',1,'WindowsFormsApp1::Form1']]]
];
