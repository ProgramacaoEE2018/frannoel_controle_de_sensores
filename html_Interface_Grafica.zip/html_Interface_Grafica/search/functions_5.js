var searchData=
[
  ['groupbox1_5fenter',['groupBox1_Enter',['../class_windows_forms_app1_1_1_form1.html#ac3007b7fc3ae8e3dcee23831d354879c',1,'WindowsFormsApp1::Form1']]],
  ['groupbox2_5fenter',['groupBox2_Enter',['../class_windows_forms_app1_1_1_form1.html#a16754d2ca0e07faf7bf7cda73d9f4c57',1,'WindowsFormsApp1::Form1']]]
];
