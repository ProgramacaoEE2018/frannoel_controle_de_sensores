var files_dup =
[
    [ "Form1.cs", "_form1_8cs.html", [
      [ "Form1", "class_windows_forms_app1_1_1_form1.html", "class_windows_forms_app1_1_1_form1" ]
    ] ],
    [ "Form1.Designer.cs", "_form1_8_designer_8cs.html", [
      [ "Form1", "class_windows_forms_app1_1_1_form1.html", "class_windows_forms_app1_1_1_form1" ]
    ] ],
    [ "Program.cs", "_program_8cs.html", [
      [ "Program", "class_windows_forms_app1_1_1_program.html", "class_windows_forms_app1_1_1_program" ]
    ] ]
];