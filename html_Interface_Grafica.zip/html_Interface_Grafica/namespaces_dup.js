var namespaces_dup =
[
    [ "WindowsFormsApp1", "namespace_windows_forms_app1.html", null ]
];